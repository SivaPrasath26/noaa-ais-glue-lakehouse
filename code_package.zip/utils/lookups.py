TRANSCEIVER_CLASS = {
    "A": "Commercial Vessel (Class A – SOLAS, high power, SOTDMA)",
    "B": "Recreational/Small Vessel (Class B – CSTDMA, low power)",
    "B+": "Enhanced Class B (Class B/SO – SOTDMA, small commercial/recreational)"
}
